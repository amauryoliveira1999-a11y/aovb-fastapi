from fastapi import FastAPI

app = FastAPI(title="AOVB Real Estate Connect API", version="1.0.0")

@app.get("/")
def root():
    return {"message": "AOVB Real Estate Connect API - Online"}
