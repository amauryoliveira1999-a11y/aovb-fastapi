async function getStatus() {
  const res = await fetch('/status');
  const data = await res.json();
  document.getElementById('status').textContent = data.status;
  document.getElementById('version').textContent = data.version;
  document.getElementById('uptime').textContent = data.uptime;
  document.getElementById('memory').textContent = data.memory_usage;
}

async function viewLogs() {
  const res = await fetch('/logs');
  const text = await res.text();
  document.getElementById('logs').textContent = text;
}
