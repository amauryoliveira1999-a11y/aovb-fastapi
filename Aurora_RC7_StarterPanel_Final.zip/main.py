from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import os, time, psutil

app = FastAPI(title="AOVB Aurora RC7 - Web Cloud Control")

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

LOG_FILE = "logs/runtime.log"
os.makedirs("logs", exist_ok=True)

def log_event(msg: str):
    with open(LOG_FILE, "a") as f:
        f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")

@app.on_event("startup")
def startup_event():
    log_event("🚀 Sistema iniciado - Aurora RC7 ativo")

@app.get("/")
def root():
    log_event("Acesso à rota raiz /")
    return {"message": "AOVB Aurora RC7 - Online"}

@app.get("/status")
def status():
    uptime = time.strftime("%H:%M:%S", time.gmtime(time.time() - psutil.boot_time()))
    memory = psutil.virtual_memory().percent
    log_event("Consulta de status /status")
    return {"status": "running", "version": "RC7", "uptime": uptime, "memory_usage": f"{memory}%"}

@app.get("/panel", response_class=HTMLResponse)
def panel(request: Request):
    log_event("Painel acessado /panel")
    return templates.TemplateResponse("panel.html", {"request": request})

@app.get("/logs")
def get_logs():
    log_event("Visualização de logs /logs")
    return FileResponse(LOG_FILE)
