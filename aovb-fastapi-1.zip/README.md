# AOVB Real Estate API
API jurídica-imobiliária baseada em FastAPI.
Endpoints principais:
- `/` - Status
- `/interpreta_matricula` - Recebe texto da matrícula e retorna análise.