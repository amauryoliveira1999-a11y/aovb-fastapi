setInterval(()=>{fetch('/status').then(r=>r.json()).then(d=>{
document.getElementById('uptime').textContent=d.uptime;
document.getElementById('cpu').textContent=d.cpu_usage+'%';
document.getElementById('mem').textContent=d.memory_usage+'%';
});},3000);