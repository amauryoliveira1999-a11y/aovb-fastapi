from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import psutil, datetime

app = FastAPI(title="Aurora RC7 Fix Render")

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

start_time = datetime.datetime.now()

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    uptime = datetime.datetime.now() - start_time
    cpu = psutil.cpu_percent()
    mem = psutil.virtual_memory().percent
    return templates.TemplateResponse("index.html", {
        "request": request,
        "uptime": str(uptime).split('.')[0],
        "cpu": cpu,
        "mem": mem
    })

@app.get("/status")
async def status():
    uptime = datetime.datetime.now() - start_time
    return {
        "status": "Aurora RC7 Online",
        "uptime": str(uptime).split('.')[0],
        "cpu_usage": psutil.cpu_percent(),
        "memory_usage": psutil.virtual_memory().percent
    }
