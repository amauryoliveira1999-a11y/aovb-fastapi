# AOVB + AuroraMemory RC7

Sistema FastAPI com memória persistente integrada (RC7).

## Endpoints

- `GET /` → Status do serviço
- `POST /memory/store` → Armazena dados na memória
- `GET /memory/retrieve` → Recupera dados armazenados

## Exemplo de uso
curl -X POST https://aovb-fastapi.onrender.com/memory/store \
     -H "Content-Type: application/json" \
     -d '{"user":"amaury","data":"Aurora RC7 funcionando!"}'
