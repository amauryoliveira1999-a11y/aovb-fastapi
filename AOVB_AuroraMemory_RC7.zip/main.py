from fastapi import FastAPI, Request
import json, os

app = FastAPI(title="AOVB FastAPI + AuroraMemory RC7", version="1.0")

MEMORY_FILE = "memory.json"

def load_memory():
    if os.path.exists(MEMORY_FILE):
        with open(MEMORY_FILE, "r") as f:
            return json.load(f)
    return {}

def save_memory(data):
    with open(MEMORY_FILE, "w") as f:
        json.dump(data, f, indent=4)

@app.post("/memory/store")
async def store_memory(request: Request):
    body = await request.json()
    memory = load_memory()
    memory.update(body)
    save_memory(memory)
    return {
        "status": "success",
        "message": "Memória armazenada com sucesso ✅",
        "data": memory,
    }

@app.get("/memory/retrieve")
async def retrieve_memory():
    memory = load_memory()
    return {"status": "success", "memory": memory}

@app.get("/")
async def root():
    return {
        "service": "AOVB FastAPI + AuroraMemory RC7",
        "status": "online ✅",
        "endpoints": ["/memory/store", "/memory/retrieve"],
    }
