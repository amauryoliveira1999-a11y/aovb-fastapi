from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import json, os

app = FastAPI(title="AOVB FastAPI + AuroraMemory RC7 WebConnect", version="1.0")

MEMORY_FILE = "memory.json"
templates = Jinja2Templates(directory="templates")

app.mount("/static", StaticFiles(directory="static"), name="static")

def load_memory():
    if os.path.exists(MEMORY_FILE):
        with open(MEMORY_FILE, "r") as f:
            return json.load(f)
    return []

def save_memory(data):
    with open(MEMORY_FILE, "w") as f:
        json.dump(data, f, indent=4)

@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    return templates.TemplateResponse("panel.html", {"request": request, "data": load_memory()})

@app.post("/memory/store")
async def store_memory(request: Request):
    body = await request.json()
    memory = load_memory()
    memory.append(body)
    save_memory(memory)
    return {"status": "success", "message": "Memória armazenada com sucesso ✅", "data": memory}

@app.get("/memory/retrieve")
async def retrieve_memory():
    return {"status": "success", "memory": load_memory()}

@app.post("/panel/save")
async def panel_save(request: Request, user: str = Form(...), message: str = Form(...)):
    memory = load_memory()
    memory.append({"user": user, "message": message})
    save_memory(memory)
    return RedirectResponse(url="/panel", status_code=303)

@app.get("/panel", response_class=HTMLResponse)
async def show_panel(request: Request):
    return templates.TemplateResponse("panel.html", {"request": request, "data": load_memory()})
